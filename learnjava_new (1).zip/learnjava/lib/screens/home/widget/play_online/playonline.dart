import 'package:flutter/material.dart';

class PlayOnLineWidget extends StatelessWidget {
  const PlayOnLineWidget({super.key,this.index});
  final int? index;

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
